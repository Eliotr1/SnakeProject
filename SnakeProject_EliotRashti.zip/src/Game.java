import java.awt.*;
import java.util.Scanner;
import java.util.Random;

// the class manages the game state, mechanics and user interaction.
public class Game {
    private final int rows = 10;
    private final int cols = 10;
    private final char EMPTY = '.';
    private final char SNAKE_BODY = 'o';
    private final char FOOD = '*';
    private char[][] board = new char[rows][cols];
    private Snake snake;
    private Food food;
    private boolean gameOver = false;

    // Initializes the board (uses initializeBoard() method) and places the snake and food at their starting points
    public Game() {
        initializeBoard();
        snake = new Snake(5, 5);
        food = new Food(3, 3);
    }

    // Initializes and creates the board
    private void initializeBoard() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                board[i][j] = EMPTY;
            }
        }
    }

    //Spawns food randomly on the board after each time the snake eats food
    private void spawnFood() {
        Random random = new Random();
        int x = random.nextInt(cols);
        int y = random.nextInt(rows);
        while (board[y][x] == SNAKE_BODY) {
            x = random.nextInt(cols);
            y = random.nextInt(rows);
        }
        food.setPosition(x, y);
    }

    // Method for board display and for drawing the snake and food on the board
    private void displayBoard() {
        // Clear the board
        initializeBoard();
        // Draw snake
        for (Point p : snake.sBody) {
            board[p.y][p.x] = SNAKE_BODY;
        }
        // Draw food
        board[food.getPosition().y][food.getPosition().x] = FOOD;
        // Print the board
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Method which checks for collision, if the snake hits the wall or if the snake hits himself  game is over, and it also checks if he eats the food, anf if yes spawns new food
    private void checkCollision() {
        Point head = snake.sBody.getFirst();
        // Check if the snake hits the wall
        if (head.x < 0 || head.x >= cols || head.y < 0 || head.y >= rows) {
            gameOver = true;
        }
        // Check if the snake hits itself
        for (int i = 1; i < snake.sBody.size(); i++) {
            if (head.equals(snake.sBody.get(i))) {
                gameOver = true;
                break;
            }
        }
        // Check if the snake eats the food, if it does, spawns new food
        if (((Point) head).equals(food.getPosition())) {
            snake.sBody.add(food.getPosition());
            spawnFood();
        }
    }

    //Method for user input and gameplay
    public void play() {
        Scanner in = new Scanner(System.in);
        //Asks user for his name(username), and welcomes him and gives instructions for the game
        System.out.print("Please enter your name:");
        String username = in.next();
        System.out.println("Welcome, " + username + "! Let's start the game.");
        System.out.println("Instructions: W- up, S- down, D- right, A- left");

        // Asks from user to insert his next move while the game isn't over
        while (!gameOver) {
            displayBoard();
            char direction = in.next().charAt(0);
            snake.move(direction);
            checkCollision();
        }
        in.close();
        // Ending of game message with final score for when game is over
        System.out.println("Game Over! Your Score: " + (snake.sBody.size() - 1));
    }
}
