import java.awt.Point;
import java.util.LinkedList;

//Class representing the snake in the game
public class Snake extends GameObject implements Movable {

    // LinkedList to store the segments of the snake's body.
    public LinkedList<Point> sBody;
    // Constructs a Snake object with the initial position and body segment.
    public Snake(int x, int y) {
        super(x, y);
        sBody = new LinkedList<>();
        sBody.add(new Point(x, y));
    }

    //Implementation of the move method in the Snake class
    // Moves the snake in the specified direction.
    // Parameters:
    //   direction - A character representing the direction to move the snake ('W' for up, 'S' for down, 'A' for left, 'D' for right).
    public void move(char direction) {
        // Gets the current head of the snake.
        Point head = sBody.getFirst();
        // Creates a new point representing the new head of the snake, initialized with the current head's coordinates.
        Point newHead = new Point(head);

        switch (direction) {
            case 'W': //Up
                newHead.y--;
                break;
            case 'S': //Down
                newHead.y++;
                break;
            case 'A': //Left
                newHead.x--;
                break;
            case 'D': //Right
                newHead.x++;
                break;
        }
        // Add the new head to the beginning of the snake's body.
        sBody.addFirst(newHead);
        // Remove the last segment of the snake's body to maintain its length.
        sBody.removeLast();
        // Update the position of the snake to match the new head position.
        position.setLocation(newHead);

    }

}
