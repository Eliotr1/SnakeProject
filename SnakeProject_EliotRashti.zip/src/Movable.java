// Interface for objects that can move on the game board
public interface Movable {
    // Moves the object based on the given direction.
    void move(char direction);
}
