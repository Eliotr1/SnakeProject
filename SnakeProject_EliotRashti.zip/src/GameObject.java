import java.awt.Point;
// Abstract class representing common properties and behaviors of game objects
public abstract class GameObject {
    protected Point position;

    //Conversion of the position parameters from ints to Points
    public GameObject(int x, int y){
        position = new Point(x,y);
    }

    //Gets the position Points
    public Point getPosition(){
        return position;
    }

    //Sets position points location
    public void setPosition(int x, int y){
        position.setLocation(x,y);
    }

}
