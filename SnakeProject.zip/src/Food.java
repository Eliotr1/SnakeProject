//Class represents the food in the game
public class Food extends GameObject {
    public Food(int x, int y){
        super(x, y);
    }

}
