// Interface for objects that can move on the game board
public interface Movable {
    void move(char direction);
}
