import java.awt.Point;
import java.util.LinkedList;

//Class representing the snake in the game
public class Snake extends GameObject implements Movable {
    public LinkedList<Point> sBody;
    public Snake(int x, int y) {
        super(x, y);
        sBody = new LinkedList<>();
        sBody.add(new Point(x, y));
    }

    //Implementation of the move method in the Snake class
    public void move(char direction) {
        Point head = sBody.getFirst();
        Point newHead = new Point(head);

        switch (direction) {
            case 'W': //Up
                newHead.y--;
                break;
            case 'S': //Down
                newHead.y++;
                break;
            case 'A': //Left
                newHead.x--;
                break;
            case 'D': //Right
                newHead.x++;
                break;
        }

        sBody.addFirst(newHead);
        sBody.removeLast();
        position.setLocation(newHead);

    }

}
